# Minimal Controller

A local Codex plugin that reproduces the reference controller's core interaction:

1. Emit an instruction and exact return schema.
2. Accept one JSON response.
3. Reject invalid shapes and repeat the previous instruction.
4. Advance only after validation.
5. Produce a generated script and transaction receipt without executing the script.

## Requirements

- Python 3.10 or newer available as `python` on `PATH`.
- Codex with local plugin support.

## Local MCP server

The plugin launches `python server.py` over stdio using `.mcp.json`. It has no third-party Python dependencies and does not open a network port.

Receipts are stored under `%LOCALAPPDATA%\ExecutionContractController\receipts` on Windows. Set `ECC_DATA_DIR` to override that location.

## Tests

```powershell
python -m unittest -v test_controller.py
```

Generated scripts are data. Review them separately; transaction completion does not authorize execution.
