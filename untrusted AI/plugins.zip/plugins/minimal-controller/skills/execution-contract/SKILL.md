---
name: execution-contract
description: Run an objective through the local Minimal Controller's deterministic instruction and response loop.
---

# Execution Contract

Use the controller whenever the user asks to apply an execution contract, controlled interrogation, deterministic solver procedure, or this plugin by name.

1. Convert the user's objective into a concise desired-state description and call `controller_start` exactly once.
2. Preserve the returned `transaction_id` for the entire interaction.
3. Read the controller's `instruction`, contextual fields, and `return_schema`.
4. Perform only the requested intellectual operation. Do not invent or skip stages.
5. Call `controller_respond` with a `response` object containing exactly the keys required by `return_schema`.
6. If the result contains `error` and `repeat`, correct the response and resubmit it without advancing independently.
7. Repeat until the controller returns `status: complete`.
8. Present the generated script to the user as a reviewable artifact. Do not execute it merely because the transaction completed.
9. Use `controller_status` when state is uncertain and `controller_receipt` when the user asks for the interaction record.

The controller's current instruction, schema, and transaction state are authoritative. Never claim completion before it returns `status: complete`.
