# Semantic Runtime

One deterministic MCP tool: `transaction(value, response?)`.

## Apps Script execution mode

Set `SEMANTIC_RUNTIME_MODE=apps_script` and `SEMANTIC_APPS_SCRIPT_URL` to the
deployed Google Apps Script `/exec` URL. MCP then sends `{terminal, value,
response}` to Apps Script, which performs the transition and writes the Sheet.
The MCP result is intentionally empty; the terminal is the sole interaction
surface. If the mode is unset, the legacy local runner remains available for
compatibility while Apps Script deployment is validated.

The current prototype also accepts a terminal ID as `value`, for example
`transaction(value="2", response="CONTINUE")`. Start a script explicitly with
an alias and terminal first. The server retrieves that terminal's current token.
See `apps-script/PUSH-SETUP.md` for the outbound Apps Script renderer. It needs
no additional tunnel: the laptop sends the render to Google's web app endpoint.
Unconfigured delivery returns PENDING_RENDER, not an updated-Sheet claim.
The address/ack routes below remain legacy prototype routes, not the current
agent interaction path.

Every nonterminal result includes `commands`: one precomputed OutToken per
available response. The response selects the transition while the screen is
rendered; it is not stored in the OutToken or encoded address.

When a transaction is initialized with `terminal`, its result also includes one
relative `/resolve/<encoded-address>` URL per response. Each address contains
only the selected OutToken and terminal. Resolving it returns a stable
`PENDING_ACK` delivery containing the terminal and next
render. Repeating the GET returns the same delivery. After Apps Script writes
that result to the Sheet, it posts `{"delivery_id":"..."}` to `/ack`; only then
does the old address become consumed and return HTTP 410.

- Codex starts `server.py` through the plugin's stdio configuration.
- Other local agents connect to `http://127.0.0.1:8788/mcp`.
- Service readiness is available at `http://127.0.0.1:8788/health`.
- A Secure MCP Tunnel may target the same `/mcp` URL for authorized remote agents.

Start the shared local service with:

```powershell
.\start-local-server.ps1
```

The service remains bound to loopback. Do not bind it to a public interface; use the authenticated tunnel for remote access.

## Terminal routing

MCP tool calls never return screens, options, commands, or tokens to the agent.
They return only `AVAILABLE_ON_TERMINAL`, the terminal identifier, and its
canonical Sheet URL. The full result is held in the server outbox for Apps
Script to read from `GET /terminal/<id>`. After writing the Sheet, Apps Script
posts the delivery identifier to `POST /ack`.

Canonical terminal names, tab IDs, and URLs live in
`definitions/terminals.json`.
