# Outbound renderer setup

Use PushRenderer.gs in a separate Apps Script project. Do not install it alongside
TerminalAdapter.gs or another doPost implementation. No onEdit or timer is needed.

Script properties:

- RENDERER_KEY: a newly generated shared secret, never placed in Sheet cells.
- TERMINALS_JSON: contents of definitions/terminals.json.
- LAYOUT_JSON: cell addresses for inToken, render, input, outToken. Defaults are
  B3, B4, B5, B6. The deployed shared terminal uses P1, C9, D15, P2
  respectively; P is hidden and D15:J16 is the command display.
  Rows 15 and 16 are 64 pixels each so multi-choice commands remain visible.

Deploy as a web app executing as the owner, accessible to the external server.
The endpoint validates RENDERER_KEY before any Sheet access. Treat its URL and
key as configuration, not as agent instructions.

Runtime environment:

The installed service loads %LOCALAPPDATA%/SemanticRuntime/renderer.json,
containing url and key_file. The key itself stays in the private renderer.key
file, not in this document or the spreadsheet.

- SEMANTIC_RENDERER_URL: optional override of the configured deployment URL.
- SEMANTIC_RENDERER_KEY_FILE: private local file containing the same RENDERER_KEY.

Start: transaction(value={alias: "demo"}, terminal=2).
Continue: transaction(value="2", response="CONTINUE").
Rerender: transaction(value="2").

For clients whose cached tool schema lacks terminal, start MIC on Worker-2 with:

```json
{"value":"eyJiaW5kaW5ncyI6e30sInNjcmVlbiI6IlNUQVJUIiwic2NyaXB0IjoibWljLWNvbnRyb2xsZXIiLCJzdGVwIjowLCJ0ZXJtaW5hbCI6MiwidmVyc2lvbiI6MX0"}
```

Then send value "2" and exactly the response displayed in D15. The older
terminal-less MIC token is rejected; it does not select a shared terminal.

Terminal ID selects the current transaction. One active transaction per terminal;
starting a script replaces it. Current state is in memory and resets on restart.
Only the displayed response is accepted. A failed renderer call does not commit
the next state. Repeating the call retries that transition. Replies contain only
terminal receipts, never screen content. Without renderer configuration, receipts
say PENDING_RENDER rather than falsely claiming the Sheet was updated.

Secure MCP handles agent calls. The server contacts Google over outbound HTTPS;
Cloudflare, URL-action addresses, and Drive polling are not used by this path.
