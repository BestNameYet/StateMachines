/** Receive one server delivery; never call the private runtime from Google. */
function doPost(event) {
  try {
    const request = JSON.parse(event.postData.contents);
    const properties = PropertiesService.getScriptProperties();
    const key = properties.getProperty('RENDERER_KEY');
    if (!key || request.key !== key) return rendererReply({status: 'DENIED'});
    renderTerminal(request.delivery, properties);
    return rendererReply({status: 'RENDERED', delivery_id: request.delivery.delivery_id});
  } catch (error) {
    return rendererReply({status: 'RENDER_FAILED'});
  }
}

/** Resolve the terminal tab and populate its four-cell screen abstraction. */
function renderTerminal(delivery, properties) {
  if (!delivery || delivery.status !== 'PENDING_ACK') throw new Error('Invalid delivery');
  const directory = JSON.parse(properties.getProperty('TERMINALS_JSON'));
  const terminal = directory.terminals[String(delivery.terminal)];
  if (!terminal) throw new Error('Unknown terminal');
  const sheet = SpreadsheetApp.openById(directory.spreadsheet_id).getSheetById(terminal.gid);
  if (!sheet) throw new Error('Missing terminal');
  const layout = JSON.parse(properties.getProperty('LAYOUT_JSON') ||
    '{"inToken":"B3","render":"B4","input":"B5","outToken":"B6"}');
  writeTerminalCells(sheet, layout, delivery);
  SpreadsheetApp.flush();
}

/** Write state and displayed response commands; agent input remains in MCP. */
function writeTerminalCells(sheet, layout, delivery) {
  const result = delivery.result;
  const commands = (result.options || []).map(function(option) {
    return 'transaction({"value":' + JSON.stringify(String(delivery.terminal)) +
      ',"response":' + JSON.stringify(option) + '})';
  });
  sheet.getRange(layout.inToken).setValue(result.in_token);
  sheet.getRange(layout.render).setValue(result.render);
  sheet.getRange(layout.input).setValue(commands.join('\n') || 'SCRIPT COMPLETE');
  sheet.getRange(layout.outToken).setValue(JSON.stringify(result.commands.map(function(command) {
    return command.value;
  })));
}

/** Return only a transport acknowledgement, never the screen content. */
function rendererReply(value) {
  return ContentService.createTextOutput(JSON.stringify(value)).setMimeType(ContentService.MimeType.JSON);
}
