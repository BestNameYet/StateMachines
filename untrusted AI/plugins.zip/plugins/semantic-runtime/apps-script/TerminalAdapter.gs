/** Receive a virtual-menu click; return only the terminal location to its caller. */
function doGet(e) {
  try {
    const config = readConfig();
    const terminal = terminalLocation(config, e.parameter.terminal);
    if (!e.parameter.script && !e.parameter.address) return showMenu(config, terminal);
    const delivery = receiveDelivery(config, terminal, e.parameter);
    renderDelivery(config, terminal, delivery);
    acknowledgeDelivery(config, delivery.delivery_id);
    return jsonReply({status: 'AVAILABLE_ON_TERMINAL', terminal: terminal.id, terminal_url: terminal.url});
  } catch (error) {
    return jsonReply({status: 'DELIVERY_FAILED', error: String(error.message || error)});
  }
}

/** Execute one stateless MCP request; the terminal is the only result surface. */
function doPost(e) {
  try {
    var request = JSON.parse(e.postData.contents || '{}');
    var config = readConfig();
    var terminal = terminalLocation(config, request.terminal);
    var result = srTransaction(request.value, request.response, terminal.id);
    renderResult(config, terminal, result);
    return jsonReply({status: 'RECEIVED', terminal: terminal.id});
  } catch (error) {
    return jsonReply({status: 'ERROR', error: String(error.message || error)});
  }
}

/** Adapt the pure engine result to the existing terminal writer contract. */
function renderResult(config, terminal, result) {
  renderDelivery(config, terminal, {status: 'PENDING_ACK', result: result});
}

/** Load deployment settings; never store server credentials in Sheet cells. */
function readConfig() {
  const properties = PropertiesService.getScriptProperties();
  const required = ['RUNTIME_BASE_URL', 'TERMINALS_JSON', 'LAYOUT_JSON'];
  required.forEach(function(key) {
    if (!properties.getProperty(key)) throw new Error('Missing setting: ' + key);
  });
  const base = properties.getProperty('RUNTIME_BASE_URL').replace(/\/$/, '');
  if (!/^https:\/\//.test(base)) throw new Error('Runtime must be reachable over HTTPS');
  return {
    base: base,
    bearer: properties.getProperty('RUNTIME_BEARER_TOKEN') || '',
    directory: JSON.parse(properties.getProperty('TERMINALS_JSON')),
    layout: JSON.parse(properties.getProperty('LAYOUT_JSON')),
    manifestId: properties.getProperty('MANIFEST_SPREADSHEET_ID') || '1hOBZIrEEzFzpB58Joc5p2IduIB5dd3ZT4v8YxX5UzaU',
    manifestTab: properties.getProperty('MANIFEST_TAB') || 'Inventory',
    webUrl: ScriptApp.getService().getUrl()
  };
}

/** Resolve a terminal identifier through the shared canonical directory. */
function terminalLocation(config, identifier) {
  const id = String(identifier);
  const location = config.directory.terminals[id];
  if (!location) throw new Error('Unknown terminal: ' + id);
  const spreadsheet = config.directory.spreadsheet_id;
  return {id: id, gid: location.gid, name: location.name, spreadsheet: spreadsheet,
    url: 'https://docs.google.com/spreadsheets/d/' + spreadsheet + '/edit?gid=' + location.gid};
}

/** Display terminal-bound start buttons; choosing a link initializes that script. */
function showMenu(config, terminal) {
  const items = availableScripts(config).map(function(entry) {
    const link = config.webUrl + '?terminal=' + encodeURIComponent(terminal.id) +
      '&script=' + encodeURIComponent(entry.key);
    return '<li><a href="' + escapeHtml(link) + '">' + escapeHtml(entry.name) + '</a></li>';
  }).join('');
  return HtmlService.createHtmlOutput('<h2>Terminal ' + escapeHtml(terminal.id) + '</h2>' +
    (items ? '<ul>' + items + '</ul>' : '<p>No scripts found locally or in Drive.</p>'));
}

/** Start via MCP, or resolve an already precomputed OutToken address. */
function receiveDelivery(config, terminal, parameters) {
  if (parameters.address) {
    const delivery = requestRuntime(config, '/resolve/' + encodeURIComponent(parameters.address));
    if (String(delivery.terminal) !== terminal.id) throw new Error('Terminal/address mismatch');
    return delivery;
  }
  const matches = availableScripts(config).filter(function(entry) { return entry.key === parameters.script; });
  if (matches.length !== 1) throw new Error('Script key not found or duplicated in manifest');
  const rpc = requestRuntime(config, '/mcp', {
    jsonrpc: '2.0', id: 1, method: 'tools/call',
    params: {name: 'transaction', arguments: {value: matches[0].value, terminal: Number(terminal.id)}}
  });
  if (rpc.error || !rpc.result || rpc.result.isError) throw new Error('Runtime start failed');
  return requestRuntime(config, '/terminal/' + encodeURIComponent(terminal.id));
}

/** Combine the laptop's installed catalog with Drive, showing each script version once. */
function availableScripts(config) {
  const local = requestRuntime(config, '/scripts').scripts;
  return mergeScripts(local, driveScripts(config));
}

/** Read Drive script pointers from the existing manifest's six-column inventory. */
function driveScripts(config) {
  const sheet = SpreadsheetApp.openById(config.manifestId).getSheetByName(config.manifestTab);
  if (!sheet) throw new Error('Manifest tab missing');
  const count = Math.max(0, sheet.getLastRow() - 6);
  if (!count) return [];
  return scriptRows(sheet.getRange(7, 1, count, 6).getValues()).map(function(row) {
    return {key: String(row[0]), name: String(row[1]), value: scriptEntry(String(row[0]))};
  });
}

/** Use script ID and version as identity, independent of filename, alias, or terminal. */
function scriptIdentity(address) {
  if (typeof address.script !== 'string' || !address.script ||
      !Number.isInteger(address.version) || address.version < 1) {
    throw new Error('Script entry needs a script ID and positive integer version');
  }
  return JSON.stringify([address.script, address.version]);
}

/** Resolve a Drive launch value to the same identity used by the local catalog. */
function entryIdentity(value, aliases) {
  if (typeof value === 'object') {
    if (!aliases[value.alias]) throw new Error('Drive entry references an uninstalled alias: ' + value.alias);
    return scriptIdentity(aliases[value.alias]);
  }
  const bytes = Utilities.base64DecodeWebSafe(value);
  return scriptIdentity(JSON.parse(Utilities.newBlob(bytes).getDataAsString('UTF-8')));
}

/** Deduplicate both sources; a matching Drive entry supplies the display name and launch value. */
function mergeScripts(local, drive) {
  const aliases = Object.create(null);
  const merged = new Map();
  local.forEach(function(entry) {
    aliases[entry.alias] = entry.entry;
    const identity = scriptIdentity(entry.entry);
    if (!merged.has(identity)) merged.set(identity, {
      key: identity, name: entry.alias, value: {alias: entry.alias}, sources: ['local']
    });
  });
  drive.forEach(function(entry) {
    const identity = entryIdentity(entry.value, aliases);
    const previous = merged.get(identity);
    if (previous && previous.sources.indexOf('drive') >= 0) return;
    merged.set(identity, {key: identity, name: entry.name, value: entry.value,
      sources: previous ? ['local', 'drive'] : ['drive']});
  });
  return Array.from(merged.values()).sort(function(a, b) { return a.name.localeCompare(b.name); });
}

/** Select native script spreadsheets by folder path, excluding folders and other artifacts. */
function scriptRows(rows) {
  return rows.filter(function(row) {
    return row[2] === 'application/vnd.google-apps.spreadsheet' &&
      /^Scripts(?:\/|$)/.test(String(row[3]));
  });
}

/** Recover a serialized entry token or alias object from the script's Runtime!A1. */
function scriptEntry(fileId) {
  const sheet = SpreadsheetApp.openById(fileId).getSheetByName('Runtime');
  if (!sheet) throw new Error('Script has no Runtime tab: ' + fileId);
  return parseScriptEntry(sheet.getRange('A1').getValue());
}

/** Validate the explicit launch value; never infer an alias from a filename. */
function parseScriptEntry(raw) {
  const text = String(raw).trim();
  if (!text) throw new Error('Script entry is empty');
  if (text.charAt(0) !== '{') return text;
  const value = JSON.parse(text);
  if (Object.keys(value).length !== 1 || typeof value.alias !== 'string' || !value.alias.trim()) {
    throw new Error('Script entry must be a token or {"alias":"installed-entry"}');
  }
  return value;
}

/** Perform one authenticated server request and reject failed HTTP responses. */
function requestRuntime(config, path, payload) {
  const options = {method: payload ? 'post' : 'get', muteHttpExceptions: true,
    headers: config.bearer ? {Authorization: 'Bearer ' + config.bearer} : {}};
  if (payload) {
    options.contentType = 'application/json';
    options.payload = JSON.stringify(payload);
  }
  const response = UrlFetchApp.fetch(config.base + path, options);
  if (response.getResponseCode() !== 200) throw new Error('Runtime HTTP ' + response.getResponseCode());
  return JSON.parse(response.getContentText());
}

/** Write one delivery to the configured cells, preserving the agent handle. */
function renderDelivery(config, terminal, delivery) {
  if (delivery.status !== 'PENDING_ACK' || !delivery.result) throw new Error('Invalid delivery');
  const sheet = SpreadsheetApp.openById(terminal.spreadsheet).getSheetById(terminal.gid);
  if (!sheet) throw new Error('Terminal tab missing');
  const layout = config.layout;
  const handle = String(sheet.getRange(layout.handle).getValue()).trim();
  sheet.getRange(layout.banner).setValue(handle ? 'IN USE BY: ' + handle : 'TERMINAL ' + terminal.id);
  sheet.getRange(layout.inToken).setValue(delivery.result.in_token);
  sheet.getRange(layout.render).setValue(delivery.result.render);
  writeActionLinks(config, sheet.getRange(layout.actions), terminal, delivery.result);
  sheet.getRange(layout.outToken).setValue(JSON.stringify(delivery.result.commands.map(function(command) {return command.value;})));
  SpreadsheetApp.flush();
}

/** Render response labels as hyperlinks containing only precomputed OutTokens. */
function writeActionLinks(config, cell, terminal, result) {
  const options = result.options || [];
  const addresses = result.addresses || [];
  if (options.length !== addresses.length) throw new Error('Missing precomputed action addresses');
  if (!options.length) return cell.setValue('SCRIPT COMPLETE');
  const text = options.join('\n');
  const builder = SpreadsheetApp.newRichTextValue().setText(text);
  let offset = 0;
  options.forEach(function(label, index) {
    const address = addresses[index].replace(/^\/resolve\//, '');
    const link = config.webUrl + '?terminal=' + encodeURIComponent(terminal.id) + '&address=' + encodeURIComponent(address);
    builder.setLinkUrl(offset, offset + label.length, link);
    offset += label.length + 1;
  });
  cell.setRichTextValue(builder.build());
}

/** Commit consumption only after the Sheet write and flush succeeded. */
function acknowledgeDelivery(config, deliveryId) {
  const reply = requestRuntime(config, '/ack', {delivery_id: deliveryId});
  if (reply.status !== 'ACKNOWLEDGED') throw new Error('Acknowledgement failed');
}

/** Produce a JSON notice with no screen, response options, or continuation tokens. */
function jsonReply(value) {
  return ContentService.createTextOutput(JSON.stringify(value)).setMimeType(ContentService.MimeType.JSON);
}

/** Escape menu text and attributes before inserting them into HTML. */
function escapeHtml(value) {
  return String(value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
