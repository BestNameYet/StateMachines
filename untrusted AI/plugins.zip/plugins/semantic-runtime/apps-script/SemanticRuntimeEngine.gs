/** Functional Apps Script port of the token and screen transition core. */

/** Encode an address as compact URL-safe JSON. @param {Object} address @return {string} */
function srEncode(address) {
  return Utilities.base64EncodeWebSafe(JSON.stringify(address)).replace(/=+$/, '');
}

/** Decode and validate an address token. @param {string} token @return {Object} */
function srDecode(token) {
  var value;
  try { value = JSON.parse(Utilities.newBlob(Utilities.base64DecodeWebSafe(token)).getDataAsString()); }
  catch (error) { throw new Error('Invalid token'); }
  ['script', 'version', 'screen', 'bindings', 'step'].forEach(function (key) {
    if (!(key in value)) throw new Error('Token missing: ' + key);
  });
  return value;
}

/** Load one immutable JSON definition from Drive. @param {string} id @param {number} version @return {Object} */
function srLoadScript(id, version) {
  var files = DriveApp.searchFiles("title = '" + id + '.v' + version + ".json' and trashed = false");
  if (!files.hasNext()) throw new Error('Definition not found: ' + id + '.v' + version);
  return JSON.parse(files.next().getBlob().getDataAsString());
}

/** Render text with explicit bindings. @param {Object} screen @param {Object} address @return {string} */
function srRenderText(screen, address) {
  var bindings = Object.assign({}, screen.bindings || {}, address.bindings || {});
  return [screen.blurb || '', screen.text || ''].filter(String).map(function (text) {
    return text.replace(/\{([^}]+)\}/g, function (_, key) {
      return Object.prototype.hasOwnProperty.call(bindings, key) ? bindings[key] : '{' + key + '}';
    });
  }).join('\n\n');
}

/** Apply one optional response and return a pure rendered result. @param {Object|string} value @param {string=} response @param {string|number=} terminal @return {Object} */
function srTransaction(value, response, terminal) {
  var address = typeof value === 'string' ? srDecode(value) : Object.assign({}, value);
  if (terminal !== undefined) address.terminal = terminal;
  var script = srLoadScript(address.script, Number(address.version));
  var screen = script.screens[address.screen];
  if (!screen) throw new Error('Screen not found: ' + address.screen);
  if (response !== undefined) {
    if (!screen.transitions || !(response in screen.transitions)) throw new Error('Invalid response');
    address = Object.assign({}, address, {screen: screen.transitions[response], step: Number(address.step) + 1});
    script = srLoadScript(address.script, Number(address.version));
    screen = script.screens[address.screen];
  }
  var options = Object.keys(screen.transitions || {});
  return {status: screen.terminal ? 'TERMINAL' : 'WAITING_FOR_AGENT', terminal: address.terminal,
    in_token: srEncode(address), out_token: srEncode(address), render: srRenderText(screen, address),
    options: options, commands: options.map(function (option) {
      return {value: srEncode(Object.assign({}, address, {screen: screen.transitions[option], step: Number(address.step) + 1})), terminal: address.terminal};
    })};
}
