# Manifest-backed default script menu

The default Apps Script screen merges the laptop runtime's /scripts catalog
with the existing Drive Artifact Manifest. SCRIPTS_JSON is not used.
Local discovery covers installed entries in the runtime definitions directory,
not an unrestricted scan of all Desktop files. Drive discovery covers the
manifest's recursively inventoried Scripts subtree.

Deduplication uses script ID plus immutable version, not filename, Drive ID,
alias, or terminal. A matching Drive entry provides its display name and launch
value; local-only scripts remain visible. Different versions remain distinct.
Multiple aliases or Drive copies for the same version produce one menu entry.
Menu links use this shared identity so source relocation does not change the key.
Token identities are decoded from serialized entries; alias identities are
resolved using the local catalog. An unknown alias is an explicit publication
error, not silently guessed or discarded.

Settings: MANIFEST_SPREADSHEET_ID defaults to
1hOBZIrEEzFzpB58Joc5p2IduIB5dd3ZT4v8YxX5UzaU;
MANIFEST_TAB defaults to Inventory. Existing runtime and terminal settings remain.

Inventory headers are row 6; records begin at row 7, columns A:F:
Drive file ID, name, MIME type, folder path, URL, modified UTC.
Native spreadsheets under Scripts (including descendants) become menu entries.
Other artifacts and folders are excluded. Menu links carry the stable Drive file
identity and terminal ID. Clicking re-reads both sources and resolves that exact key.

Each script spreadsheet must have a Runtime tab. Runtime!A1 contains either
a serialized initial token or JSON such as {"alias":"mic-controller"}.
Its name is the display label, not a runtime address. Runtime!A1 is launch
metadata, not executable script code. The addressed versioned JSON definition
must still exist in the runner; this change does not import or install code.

availableScripts reads inventory and resolves launch values; scriptRows filters
inventory; scriptEntry reads Runtime!A1; parseScriptEntry checks launch shape;
showMenu renders links; receiveDelivery sends the recovered value to transaction.
All reads are non-mutating. No onEdit trigger is needed for menu discovery.
New inventory entries appear after the scheduled manifest refresh.

An empty Scripts inventory renders an explicit empty-state message. Missing
Runtime tabs or malformed entries produce an error rather than a guessed alias.
Deploy an updated Apps Script version to activate this code. The current Drive
inventory has no script spreadsheets; publication is separate from this change.
