param(
    [ValidateRange(1, 65535)]
    [int]$Port = 8790
)

$pluginRoot = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$python = 'C:\Users\samue\AppData\Local\Python\pythoncore-3.14-64\python.exe'
& $python (Join-Path $pluginRoot 'http_server.py') --host 127.0.0.1 --port $Port
