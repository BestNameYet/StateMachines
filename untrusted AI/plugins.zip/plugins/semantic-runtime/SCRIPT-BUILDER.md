# Guided script builder

Start with transaction(value={"alias":"script-builder"}). This alias assigns
Worker-2; an explicit terminal argument or a terminal-addressed token can select
another terminal. On clients lacking alias-object support, use the start token
below. Responses are sent through MCP, not entered into spreadsheet cells.

```json
{"value":"eyJiaW5kaW5ncyI6e30sInNjcmVlbiI6IlNUQVJUIiwic2NyaXB0Ijoic2NyaXB0LWJ1aWxkZXIiLCJzdGVwIjowLCJ0ZXJtaW5hbCI6MiwidmVyc2lvbiI6MX0"}
```

## Creator sequence

BEGIN → script ID → version → script blurb → screen bundle → entry point →
each screen's text, bindings and blurb → whole-storyboard review → SAVE → success.
Every entered value is shown for APPROVE or CANCEL. CANCEL re-enters the same
field; EXIT discards the draft. START_OVER on final review starts a fresh draft.

On value-entry screens, the command displayed in Input contains an **example**
response. Replace it with your own value; it is not a finite-choice menu.
Example: transaction({"value":"2","response":"my-procedure"}). To submit
an object/array, send its JSON text as the response string.

Bundle input:

```json
["FIRST", {"id":"IMPORTED","script":"demo","version":1,"screen":"START"}]
```

References copy versioned ordinary text screens with source provenance. Handler
screens cannot be imported. Bundle IDs must be unique. FINAL_SUCCESS is reserved
and appended automatically. The selected entry moves to the front; remaining
screens retain their relative order. This release builds a sequential storyboard,
not arbitrary branching. Imported transition maps are replaced by this sequence.

Screen configuration:

```json
{"text":"Hello {name}","bindings":{"name":"Ada"},"blurb":"Read and continue."}
```

Configure every screen, including FINAL_SUCCESS. Values in bindings are local
defaults; runtime token bindings can override them. Text and blurbs use simple
{name} placeholders. Literal JSON braces in text must be doubled: {{ and }}.
The builder validates bindings, paths, entry/reachability and success before SAVE.

SAVE publishes definitions/scripts/<id>.v<version>.json, never overwriting a
different existing version. Success displays the terminal-addressed start command.
No alias is required for the resulting script. Publication is idempotent for an
identical retry. Publication occurs before Sheet delivery: if delivery fails,
the definition can already exist; retrying SAVE with the same draft is safe.

The active Secure MCP channel targets loopback port 8790. Start-local-server.ps1
uses that same port; no second tunnel or public laptop listener is required.

Draft state is serialized in the builder token. The server's terminal-ID lookup
is still in memory: retain the latest InToken if the service restarts. There is
no durable server-side draft registry or new scheduling engine.

## Function map

- script_builder.advance: accept one typed value or navigation choice.
- collect: validate/stage a creator field.
- bundle: collect blank or referenced text screens.
- next_phase: approve staged values and choose the next field.
- compile_script: bind storyboard CONTINUE destinations and final success.
- apply_effect: publish only when the actual transaction reaches success.
- view/input_prompt/current_name: render creator instructions and examples.
- script_validation.identifier/validate_script/validate_screen/walk/reaches_success:
  validate names, text bindings, graph and success reachability.
- store.check_publish/publish_script: immutable, retry-safe definition creation.
- runner._render_builder/_text: project creator screens and populate screen defaults.

## Investigation record

Existing: fixed-choice runner and outbound four-cell Sheet renderer.
Target: a functioning typed-input creator producing runnable versioned storyboards.
Reason: fixed-choice JSON alone cannot collect user-authored text or bindings.
Break risk: legacy screen rendering, preview-triggered writes, invalid bindings,
version overwrite and delivery retry. Proof path: isolated builder tests, existing
MCP tests, renderer tests and a live start/readback; do not publish test scripts
into the live definitions directory.
