# MIS + Solver KB Query — self-contained build

This folder is the runnable reconstruction of **Minimal Instruction Set (MIS) with pre-q1 Solver-KB retrieval**.

## Canonical retrieval decision

The Solver KB query is the recovered native algorithm from the prior Execution Contract Controller: BM25-style lexical scoring over canonical retrieval metadata, deterministic exact-ID/alias boosts, record-type priors, and one-hop link expansion. It is **not** the unrelated ChatGPT-history `query.py` NumPy/GloVe corpus retriever.

## Required runtime

Everything required by this build is inside this folder. Runtime code uses only the Python standard library.

- `data/execution_knowledge_base.json` — canonical 40-record Solver execution KB with built-in retrieval benchmarks.
- `scripts/solver_query.py` — recovered/native Solver-KB query implementation.
- `scripts/solver_kb_adapter.py` — normalized MIS retrieval adapter with SHA-256 provenance.
- `scripts/retrieval_adapter.py` — fail-open retrieval service boundary from the MIS handoff.
- `scripts/mis_controller.py` — MIS transaction protocol with retrieval before q1 and `kb_retrieval` event 0.
- `scripts/server_integration.py` — registers the real adapter directly in-process.
- `scripts/server.py` — stdlib HTTP MCP-compatible tool server.
- `scripts/query_cli.py` — direct query CLI.
- `scripts/mis_cli.py` — interactive MIS transaction CLI.
- `runtime/original_execution_runtime/` — complete preserved prior execution runtime from which the native query was recovered.
- `tests/` — retrieval and end-to-end MIS tests.

## Run

```bash
python -m unittest discover -s tests -v
python scripts/query_cli.py "replace known GitHub file and commit" --top-k 8
python scripts/server.py --host 127.0.0.1 --port 8765
```

Then point an MCP client to `http://127.0.0.1:8765/mcp` (also represented by `.mcp.json`).

## Protocol invariants preserved

`controller_start(desired_state)` performs retrieval before q1, but returns the original q1 schema `{"q1":["<question>"]}`. Questions remain sequential `{"answer":"<answer>"}`. Final solver response remains `{"script":"<script>"}`. Retrieval failures are fail-open. MIS calls the retrieval service directly, never its own public MCP tool.
