---
name: mis-solver-query
description: Retrieve Solver Architecture KB context or run a deterministic MIS controller when the user needs an executable solving procedure, transaction status, or provenance receipt.
---

# MIS Solver Query

Use `retrieve_context` for a standalone search of the Solver Architecture KB.

For an executable solving procedure:

1. Convert the objective into a concise desired state and call `controller_start` exactly once.
2. Preserve its `transaction_id`. Follow each returned instruction and submit only the exact `return_schema` through `controller_respond`.
3. Continue sequentially until the controller returns completion and a final script. Use `controller_status` only when state is uncertain and `controller_receipt` when the user requests provenance.
4. Present the generated script for review. A generated script does not authorize unrelated writes, external actions, or destructive operations.
5. After the script has actually been executed, use `controller_finalize` only when a post-execution report is useful or requested.

If retrieval fails, preserve the controller's reported provenance and uncertainty rather than inventing KB support.
