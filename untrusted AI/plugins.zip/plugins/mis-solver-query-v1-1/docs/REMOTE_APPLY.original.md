# Remote Apply — Minimal Change Set

Use this as the implementation checklist on the server side.

1. Copy `scripts/retrieval_adapter.py` into the server's Python source directory.
2. Replace/merge the current MIS controller with `scripts/mis_controller.py`, preserving the server's existing persistence backend if it differs from the in-memory reference implementation. The semantic invariant is: retrieval is invoked synchronously at the start of a transaction, before q1 is emitted.
3. Create one process-wide `RetrievalService` and pass it to `MISController`.
4. Map the existing controller MCP tools to the same `MISController` methods as before. Do not add a required retrieval phase.
5. If a public retrieval tool is wanted, map it to `public_retrieve(RETRIEVAL_SERVICE, query, limit)` or the wrapper in `server_integration.py`.
6. Do **not** make the MIS call that public MCP tool. Internal retrieval must remain `RETRIEVAL_SERVICE.retrieve(...)`.
7. Until the real Solver KB adapter is ready, leave `RetrievalService()` unconfigured. `NullRetrievalAdapter` makes the controller behave like bare MIS.
8. When the real adapter is added, register it server-side. Do not expose adapter registration as model-facing update authority.
9. Run `python -m unittest discover -s tests -v` and the syntax command in `HANDOFF.md`.
10. Live acceptance check: start one transaction with the real adapter; verify receipt event 0 is `kb_retrieval`, q1 prompt includes retrieved context when matches exist, final procedure prompt includes the same retrieval context, and adapter failure still permits a bare-MIS transaction to proceed.
