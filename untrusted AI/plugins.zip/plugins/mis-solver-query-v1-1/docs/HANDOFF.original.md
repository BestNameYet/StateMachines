# MIS → Solver Architecture KB Adapter Handoff

## Purpose

This package revises the Minimal Instruction Set (MIS) controller so a future Solver Architecture knowledge-base adapter can be attached without changing the MIS transaction protocol and without recursive MCP self-calls.

**This package intentionally does not fetch, merge, reconcile, or install the large knowledge base.** The next implementation step is only to implement and register a concrete adapter against the interface below.

## Architecture

```text
user desired_state
      |
      v
MISController.start()
      |
      +--> RetrievalService.retrieve(desired_state)
      |       |
      |       +--> configured local RetrievalAdapter
      |       |       (NullRetrievalAdapter by default)
      |       |
      |       +--> normalized RetrievalResult
      |
      +--> persist compact retrieval snapshot/event
      |
      +--> q1 prompt, enriched only when matches exist
      v
existing q1 -> sequential answers -> final procedure flow
```

The internal MIS call is an ordinary Python function call. The optional public MCP retrieval tool delegates to the **same `RetrievalService` instance**, so there is one retrieval implementation and no server-to-itself MCP invocation.

## Adapter contract

Implement an object with:

```python
adapter_id: str

def retrieve_context(query: str, limit: int = 5) -> RetrievalResult | Mapping:
    ...
```

Normalized result:

```python
{
  "query": "...",                 # service normalizes to caller query
  "matches": [ {...}, ... ],      # list of provenance-bearing mappings
  "status": "ok" | "error",
  "adapter_id": "solver-kb-vN",
  "provenance": {...},
  "error": None | "concise error"
}
```

Register it server-side:

```python
from server_integration import register_retrieval_adapter
register_retrieval_adapter(SolverArchitectureAdapter(...))
```

Do not expose registration/update authority as a normal model-facing tool.

## Invariants that must not change

1. `controller_start(desired_state)` still returns the q1-generation instruction with schema `{"q1":["<question>"]}`.
2. Questions are still asked sequentially with `{"answer":"<answer>"}`.
3. The final solver request still uses `{"script":"<script>"}`.
4. Submitting the script still completes the transaction.
5. Retrieval happens **before q1 generation** but creates no extra solver-visible phase.
6. With the null adapter, empty results, adapter exceptions, or malformed adapter results, MIS continues in bare mode.
7. MIS never invokes its own public MCP retrieval tool. It calls `RetrievalService` directly in-process.

## Context/provenance behavior

When matches exist, the controller injects only:

- adapter ID,
- retrieval provenance,
- normalized matches.

The transaction also records a `kb_retrieval` internal event before the first stdout/q1 event. Errors are fail-open but visible in state/receipt.

`prospective_state()` is included as the model-safe current projection. `receipt()` remains the retrospective audit view and can be segregated by the production server's access policy.

## Public retrieval boundary

Expose `server_integration.retrieve_context(query, limit)` as the MCP retrieval tool if required. It delegates to the same `RetrievalService` used internally by MIS.

## Next-chat implementation task

The next chat/operator should:

1. obtain the actual Solver Architecture retrieval implementation and resolved KB corpus;
2. implement `SolverArchitectureAdapter.retrieve_context()` around that implementation;
3. return provenance-bearing normalized match mappings;
4. register the adapter using `register_retrieval_adapter()`;
5. run this package's tests plus adapter-specific relevance/corpus tests;
6. verify an end-to-end live MIS transaction shows `kb_retrieval` as event 0 and uses retrieved context in q1 and final-procedure generation.

The large GitHub KB fetch/merge/reconciliation is **out of scope here by design**.

## Validation

From the package root:

```bash
python -m unittest discover -s tests -v
python -m py_compile scripts/retrieval_adapter.py scripts/mis_controller.py scripts/server_integration.py
```

All tests must pass before integration into the remote server.
