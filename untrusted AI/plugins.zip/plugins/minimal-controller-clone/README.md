# Minimal Controller Clone

A local Codex plugin that combines Solver Architecture KB with a deterministic execution contract:

1. Represent the objective across the KB's explicit problem perspectives.
2. Retrieve analogous problems, broad solver families, failure modes, and validation methods.
3. Compare materially different candidate architectures and expose coverage gaps.
4. Interrogate and select the architecture against evidence, constraints, assumptions, and alternatives.
5. Generate the questions a capable model would explore when applying selected solution category X to problem Y.
6. Emit an architecture-and-domain-grounded instruction and exact return schema.
7. Reject invalid shapes and repeat the previous instruction.
8. Produce a generated solver instruction and transaction receipt without executing it.

The former generic question phase is replaced by ordered interrogation: architecture choice first, X-on-Y application exploration second. Every application-question answer must be capable of changing how X is designed or executed for Y; general subject-matter questions and goal restatements are excluded.

## Requirements

- Python 3.14 installed at `C:\Users\samue\AppData\Local\Python\pythoncore-3.14-64\python.exe`.
- Codex with local plugin support.
- `solver-architecture-kb` installed as a sibling plugin, or `SOLVER_ARCHITECTURE_KB_PATH` set to its root.

## Local MCP server

The plugin launches the installed Python interpreter over stdio using `.mcp.json`. It reads the shared Solver Architecture KB directly, so its transaction is not dependent on a second model making a generic domain lookup.

Receipts are stored under `%LOCALAPPDATA%\ExecutionContractController\receipts` on Windows. Set `ECC_DATA_DIR` to override that location.

## Tests

```powershell
python -m unittest -v test_controller.py
```

Generated scripts are data. Review them separately; transaction completion does not authorize execution.
