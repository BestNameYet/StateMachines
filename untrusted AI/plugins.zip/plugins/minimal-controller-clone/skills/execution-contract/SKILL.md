---
name: execution-contract
description: Run an objective through a deterministic controller that first maps the problem to broad solution strategies and architectures using Solver Architecture KB.
---

# Execution Contract

Use the controller whenever the user asks to apply an execution contract, controlled interrogation, deterministic solver procedure, or this plugin by name.

1. Convert the user's objective into a concise desired-state description and call `controller_start` exactly once. The controller consults Solver Architecture KB before requesting solver output.
2. Preserve the returned `transaction_id` for the entire interaction.
3. First complete the architecture-choice interrogation: compare every retrieved candidate against evidence, constraints, failure modes, assumptions, validation burden, and coverage gaps. Submit the exact selected candidate name and rationale.
4. Then conduct the X-on-Y application interrogation: treating the chosen solution category as X and the user's problem as Y, generate the questions a capable model would explore to determine how to apply X to Y. Questions must operationalize X for Y—representation mappings, category variants, algorithms, decomposition, control flow, evidence, tools, interfaces, parameters, assumptions, failures, outputs, tests, feedback, and stopping rules. Every answer must be capable of changing the design or execution of X-on-Y.
5. Answer each application question from authoritative context when available; ask the user only when the answer is unavailable and materially changes the result. Exclude generic questions about Y and questions that merely restate the goal.
6. Perform the final requested operation using the selected architecture and domain answers. Preserve provenance and uncertainty.
7. Call `controller_respond` with a `response` object containing exactly the keys required by `return_schema`.
8. If the result contains `error` and `repeat`, correct the response and resubmit it without advancing independently.
9. Repeat until the controller returns `status: complete`.
10. Present the generated solver instruction to the user as a reviewable artifact. Do not execute it merely because the transaction completed.
11. Use `controller_status` when state is uncertain and `controller_receipt` when the user asks for the interaction record.

The controller's current instruction, schema, and transaction state are authoritative. Never claim completion before it returns `status: complete`.

If `architecture_source` is `embedded-fallback` or `architecture_error` is non-null, use the Solver Architecture KB tools directly when available, and disclose that the controller could not reach the shared KB. Ask the user only for a fact that is both unavailable and capable of materially changing safe solver selection.
