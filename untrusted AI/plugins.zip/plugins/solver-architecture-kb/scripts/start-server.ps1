param([int]$Port = 8765)
$python = if ($env:CODEX_MCP_PYTHON_PATH) { $env:CODEX_MCP_PYTHON_PATH } else { 'python' }
& $python (Join-Path $PSScriptRoot 'server.py') --port $Port
