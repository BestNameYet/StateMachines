param([int]$Port = 8765)
$python = if ($env:CODEX_MCP_PYTHON_PATH) { $env:CODEX_MCP_PYTHON_PATH } else { 'python' }
$server = Start-Process -FilePath $python -ArgumentList @((Join-Path $PSScriptRoot 'server.py'),'--port',$Port) -WindowStyle Hidden -PassThru
try {
  $log = Join-Path ([IO.Path]::GetTempPath()) ('solver-kb-tunnel-' + [guid]::NewGuid() + '.log')
  $tunnel = Start-Process -FilePath 'cloudflared' -ArgumentList @('tunnel','--url',"http://127.0.0.1:$Port",'--logfile',$log) -WindowStyle Hidden -PassThru
  $deadline = (Get-Date).AddSeconds(45)
  do {
    Start-Sleep -Milliseconds 500
    if (Test-Path $log) { $match = Select-String -Path $log -Pattern 'https://[-a-z0-9]+\.trycloudflare\.com' | Select-Object -Last 1 }
  } until ($match -or (Get-Date) -gt $deadline -or $tunnel.HasExited)
  if (-not $match) { throw 'Tunnel URL was not produced. Install cloudflared or configure a named tunnel.' }
  $url = $match.Matches[0].Value
  & $python (Join-Path $PSScriptRoot 'configure_tunnel.py') $url
  Write-Host "MCP tunnel: $url/mcp"
  Wait-Process -Id $tunnel.Id
} finally {
  if (-not $server.HasExited) { Stop-Process -Id $server.Id }
}
