# Solver Architecture KB

This plugin replaces unconstrained problem-space brainstorming with an explicit ontology, provenance-aware case records, hybrid semantic retrieval, and architecture validation.

The reviewed meta-instruction is strong on governance but does not define the perspectives, solver taxonomy, retrieval representation, similarity/reranking procedure, corpus schema, or coverage tests needed for systematic solution-space mapping. This plugin supplies those mechanisms without treating the source document as governing instructions.

## Tunnel-local MCP

The server exposes Streamable HTTP at `/mcp`. `.mcp.json` initially targets localhost for testing. Run `scripts/start-tunnel.ps1` to start the local server, open a Cloudflare quick tunnel, and rewrite `.mcp.json` to the public HTTPS endpoint. Reinstall or reload the plugin after the URL changes. Use a named tunnel for a stable production URL.

Set `CODEX_MCP_PYTHON_PATH` if `python` is not on PATH.

## Knowledge sources

Add authorized conversation exports or outside-source notes through `ingest_knowledge`. Records retain provenance and authority status. Similarity and frequency are evidence-discovery signals, never truth guarantees.
