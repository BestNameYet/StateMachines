# MIS + Solver KB Query 1.2 — full-ranking remote build

This folder is the runnable **Minimal Instruction Set (MIS) controller with full-KB ranking, an external-evidence acquisition plane, and a private HTTP MCP target for OpenAI Secure MCP Tunnel**.

## Canonical retrieval decision

The query calculates a deterministic direct-relevance value `k` using BM25-style lexical scoring over canonical retrieval metadata, exact-ID and alias boosts, and record-type priors. One-hop link influence is returned separately as metadata so it cannot displace stronger direct matches. It returns all 52 complete canonical records sorted by `k DESC, id ASC`; zero-score records are retained. It is **not** a top-k projection and is not the unrelated ChatGPT-history `query.py` NumPy/GloVe retriever.

## Required runtime

Everything required by this build is inside this folder. Runtime code uses only the Python standard library.

- `data/execution_knowledge_base.json` — attached canonical 52-record Solver Architecture KB with built-in retrieval benchmarks, including official OpenAI Secure MCP Tunnel guidance.
- `data/reconciled_knowledge_base_manifest.json` — source reconciliation and provenance manifest for the attached KB.
- `scripts/solver_query.py` — native scoring plus complete-KB ranking by `k`.
- `scripts/solver_kb_adapter.py` — normalized MIS retrieval adapter with SHA-256 provenance.
- `scripts/retrieval_adapter.py` — fail-open retrieval service boundary from the MIS handoff.
- `scripts/mis_controller.py` — MIS transaction protocol with retrieval before q1 and `kb_retrieval` event 0.
- `scripts/server_integration.py` — registers the real adapter directly in-process.
- `scripts/server.py` — stdlib HTTP MCP-compatible tool server.
- `scripts/query_cli.py` — direct query CLI.
- `scripts/mis_cli.py` — interactive MIS transaction CLI.
- `runtime/original_execution_runtime/` — complete preserved prior execution runtime from which the native query was recovered.
- `tests/` — retrieval and end-to-end MIS tests.
- `remote/` — private HTTP server launcher, health check, and Secure MCP Tunnel operator guide.

## Run

```bash
python -m unittest discover -s tests -v
python scripts/query_cli.py "replace known GitHub file and commit"
python scripts/server.py --host 127.0.0.1 --port 8765
```

The private HTTP MCP target is `http://127.0.0.1:8765/mcp`. For remote OpenAI product access without public inbound exposure, follow `remote/SECURE_MCP_TUNNEL.md`.

## Epistemic architecture

The Solver KB is procedural guidance: it selects useful heuristics, constraints, capabilities, and procedures. It does not serve as evidence for externally checkable facts. Retrieval results carry `epistemic_role` and `may_support_world_claims`; every bundled record currently has the effective value `false` for the latter.

After user-only questions, the controller requires an inquiry plan. If the objective depends on current or external facts, it then requires an evidence packet whose items identify their source, locator, retrieval time, relevant content, and covered information requirements. Every requirement must be backed by external evidence or recorded as unresolved with acquisition attempts. Final synthesis receives four separate contexts: solver guidance, user-supplied facts, external evidence, and unresolved evidence.

## Protocol invariants

`controller_start(desired_state)` performs Solver-KB retrieval before q1 and returns `{"q1":["<question>"]}`. Questions remain sequential `{"answer":"<answer>"}`. The added phases use `{"inquiry_plan":...}` and then, when needed, `{"evidence":[],"unresolved":[]}`. Final solver response remains `{"script":"<script>"}`. Solver-KB retrieval failures are fail-open; external evidence gaps must be explicit. MIS calls the Solver-KB retrieval service directly, never its own public MCP tool.
