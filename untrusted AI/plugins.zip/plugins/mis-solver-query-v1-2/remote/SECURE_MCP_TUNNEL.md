# Secure MCP Tunnel deployment

This build exposes a private HTTP MCP target at `http://127.0.0.1:8765/mcp`. It is intended to remain on loopback and be reached through OpenAI Secure MCP Tunnel rather than a public inbound endpoint.

## Host preparation

1. Run `remote/start-private-server.ps1` on a host that can make outbound HTTPS connections to OpenAI.
2. Run `remote/check-private-server.ps1` and retain the non-secret health output.
3. Create or select a Secure MCP Tunnel in OpenAI Platform settings and associate it with the intended workspace or organization.
4. Run the official `tunnel-client` on this host using the tunnel ID and runtime API key, targeting `http://127.0.0.1:8765/mcp`. Follow the current official Secure MCP Tunnel guide for the client command and authentication syntax; those details are intentionally not duplicated here.
5. Confirm tunnel-client health. In the supported OpenAI product, create the developer-mode connection and select the associated tunnel.

## Security requirements

- Never place the tunnel runtime API key in this plugin, prompts, logs, KB records, or receipts.
- Keep the HTTP MCP server bound to `127.0.0.1` unless a separately reviewed private-network design requires otherwise.
- Use the tunnel only for authorized private developer-mode connections.
- Secure MCP Tunnel is not the distribution mechanism for a public plugin.

## Completion evidence

- Tunnel ID, without the runtime API key
- Healthy local `/health` response
- Non-secret tunnel-client health or doctor output
- Workspace or organization association
- Successful developer-mode connection

Official guide: https://developers.openai.com/api/docs/guides/secure-mcp-tunnels
