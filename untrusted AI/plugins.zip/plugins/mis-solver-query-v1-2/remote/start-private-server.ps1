param(
    [ValidateRange(1, 65535)]
    [int]$Port = 8765
)

$pluginRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$server = Join-Path $pluginRoot 'scripts\server.py'

python $server --host 127.0.0.1 --port $Port
