param(
    [ValidateRange(1, 65535)]
    [int]$Port = 8765
)

$health = Invoke-RestMethod -Method Get -Uri "http://127.0.0.1:$Port/health"
if ($health.status -ne 'ok' -or $health.server -ne 'mis-solver-query-v1-2') {
    throw 'Unexpected private MCP server health response.'
}
$health
