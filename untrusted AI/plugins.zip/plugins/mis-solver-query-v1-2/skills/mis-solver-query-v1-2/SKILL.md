---
name: mis-solver-query-v1-2
description: Retrieve the complete Solver Architecture KB ranked by k or run a deterministic MIS controller through local MCP or a private Secure MCP Tunnel connection while keeping procedural guidance separate from external evidence.
---

# MIS Solver Query 1.2

Use `retrieve_context` for a standalone query of the Solver Architecture KB. It always returns all 52 canonical records, including their complete record bodies, sorted by `k` descending and canonical ID ascending for ties. Do not request or impose a top-k limit. Treat every returned record as solver guidance unless its metadata explicitly says it may support world claims. The bundled v1.2 records do not.

For an executable solving procedure:

1. Convert the objective into a concise desired state and call `controller_start` exactly once.
2. Preserve its `transaction_id`. Follow each returned instruction and submit only the exact `return_schema` through `controller_respond`.
3. Use q1 only for information that must come from the user, such as authority, preferences, constraints, or unavailable inputs. Do not defer externally discoverable facts to the user.
4. When asked for an inquiry plan, identify externally checkable claims and the authoritative, sufficiently fresh sources or measurements needed to resolve them. The KB shapes this inquiry but is not evidence for those claims.
5. When asked for evidence, use appropriate external tools and sources. Account for every information requirement with sourced evidence or an explicit unresolved record containing attempted acquisition paths.
6. Continue sequentially until the controller returns completion and a final script. Keep solver guidance, user-supplied facts, external evidence, and model inference epistemically distinct. Use `controller_status` only when state is uncertain and `controller_receipt` when the user requests provenance.
7. Present the generated script for review. A generated script does not authorize unrelated writes, external actions, or destructive operations.
8. After the script has actually been executed, use `controller_finalize` only when a post-execution report is useful or requested.

If Solver-KB retrieval fails, preserve the controller's reported provenance and uncertainty and continue designing the inquiry without inventing KB support. If external evidence cannot be acquired, report the gap; do not replace it with KB records or unlabeled latent inference.

For private remote use, run the HTTP MCP server on loopback and connect it through an authorized OpenAI Secure MCP Tunnel. Never put the tunnel runtime API key in prompts, logs, configuration committed with the plugin, or transaction receipts. Read `remote/SECURE_MCP_TUNNEL.md` before configuring the tunnel host.
